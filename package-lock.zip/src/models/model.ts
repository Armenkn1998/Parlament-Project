export interface IParlament{
    id:number;
    title:string;
    description:string;
}

export interface IDepnumbers{
    id:number;
    name:string;
    day:string;
    time:string;
}

export interface ITime{
    id:number;
    title:string;
    tel:string;
}
