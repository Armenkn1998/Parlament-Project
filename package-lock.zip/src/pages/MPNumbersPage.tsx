import React from 'react'
import { Header } from '../components/Header'

export const MPNumbersPage = () => {
  return (
    <div>
      <Header/>
      MPNumbersPage</div>
  )
}
