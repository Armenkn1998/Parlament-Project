import React from 'react'
import { Header } from '../components/Header'

export const MeetingsSchedulePage = () => {
  return (
    <div>
      <Header/>
      MeetingsSchedulePage</div>
  )
}
