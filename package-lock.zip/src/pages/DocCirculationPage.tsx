import React from 'react'
import { Header } from '../components/Header'

export const DocCirculationPage = () => {
  return (
    <div>
      <Header/>
      DocCirculationPage</div>
  )
}

